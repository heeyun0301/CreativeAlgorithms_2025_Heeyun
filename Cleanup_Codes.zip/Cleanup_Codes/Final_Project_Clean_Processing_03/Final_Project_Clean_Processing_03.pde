import oscP5.*;
import netP5.*;

// ==========================================
// [User Settings]
// ==========================================
final float LOCK_DISTANCE = 20.0; 
final float MAX_DIST_THRESHOLD = 300.0; 
final int NUM_POINTS = 20; 

OscP5 oscP5;
int port = 6000; 

ArrayList<BlobData> currentFrameBlobs = new ArrayList<BlobData>();
BlobData targetBlob = null;

// [Trace System]
ArrayList<Particle> pts;
PGraphics traceLayer;  
PImage grainImage;     

// [Color Palette - Base]
color c_bg        = color(10, 10, 10);//color(53, 80, 112);   // Deep Slate Blue (Background)
color c_mesh_lock = color(240, 180, 158); // Peach (Lock Highlight)
color c_mesh_glow = color(179, 129, 132); // Mauve (Glow)
color c_mesh_core = color(255, 255, 255); // White

// [Monotone Ranges for Semantic Mapping]
color c_sem_dark  = color(90, 95, 100);    // Dark Charcoal Grey
color c_sem_light = color(245, 240, 225);  // Bright Bone/Beige

void setup() {
  size(480, 405, P3D); 
  
  oscP5 = new OscP5(this, port);
  
  smooth();
  background(c_bg);
  
  // 1. Initialize Trace Layer
  traceLayer = createGraphics(width, height); 
  traceLayer.beginDraw();
  traceLayer.background(c_bg); 
  traceLayer.endDraw();
  
  // 2. Initialize Grain Texture
  grainImage = createImage(width, height, ARGB);
  grainImage.loadPixels();
  for (int i = 0; i < grainImage.pixels.length; i++) {
    float val = random(255);
    grainImage.pixels[i] = color(val, random(15, 35)); 
  }
  grainImage.updatePixels();
  
  pts = new ArrayList<Particle>();
}

void draw() {
  // ==========================================
  // 1. Trace Layer (Particles & Fading)
  // ==========================================
  traceLayer.beginDraw();
  
  // [FADING LOGIC]
  traceLayer.noStroke();
  traceLayer.fill(c_bg, 5); 
  traceLayer.rect(0, 0, width, height);
  
  // Update Particles
  if (targetBlob != null) {
    
    // --- [NEW LOGIC] Semantic Brightness ---
    // We average X and Y to get a 0.0 - 1.0 brightness factor.
    // Similar objects -> Similar X/Y -> Similar Brightness.
    float brightnessFactor = (targetBlob.semX + targetBlob.semY) / 2.0;
    
    // Clamp to ensure it stays safe
    brightnessFactor = constrain(brightnessFactor, 0, 1);

    // Interpolate: 0.0 = Dark Grey, 1.0 = Bright Beige
    color finalSemanticColor = lerpColor(c_sem_dark, c_sem_light, brightnessFactor);
    
    for (int i=0; i<5; i++) {
       Particle newP = new Particle(targetBlob.center.x, targetBlob.center.y, i+pts.size(), i+pts.size(), finalSemanticColor);
       pts.add(newP);
    }
  }

  for (int i=pts.size()-1; i>-1; i--) {
    Particle p = pts.get(i);
    if (p.dead) {
      pts.remove(i);
    } else {
      p.update();
      p.display(traceLayer); 
    }
  }
  traceLayer.endDraw();
  
  // ==========================================
  // 2. Main Composition
  // ==========================================
  
  background(c_bg);          
  
  hint(DISABLE_DEPTH_TEST);
  image(traceLayer, 0, 0); 
  hint(ENABLE_DEPTH_TEST);
  
  if (targetBlob != null) {
    drawGlowingMesh(targetBlob);
  }
  
  hint(DISABLE_DEPTH_TEST);
  tint(255, 40); 
  image(grainImage, 0, 0);
  noTint(); 
  hint(ENABLE_DEPTH_TEST);
}

// ==========================================
// [Visual Logic] Glowing Mesh Lines
// ==========================================
void drawGlowingMesh(BlobData b) {
  float distVal = b.distance;
  float distortionAmt = 0;
  
  if (distVal > LOCK_DISTANCE) {
    distortionAmt = map(distVal, LOCK_DISTANCE, MAX_DIST_THRESHOLD, 0, 150); 
  }
  
  ArrayList<PVector> renderPoints = new ArrayList<PVector>();
  
  for (int i = 0; i < b.points.size(); i++) {
    PVector originalPt = b.points.get(i);
    float noiseX = noise(originalPt.x * 0.01, originalPt.y * 0.01, frameCount * 0.02) - 0.5;
    float noiseY = noise(originalPt.y * 0.01, originalPt.x * 0.01, frameCount * 0.02) - 0.5;
    
    float finalX = originalPt.x + (noiseX * distortionAmt * 3);
    float finalY = originalPt.y + (noiseY * distortionAmt * 3);
    
    renderPoints.add(new PVector(finalX, finalY));
  }
  
  color haloColor, coreColor;
  
  if (distVal <= LOCK_DISTANCE) {
    haloColor = c_mesh_lock; 
    coreColor = color(255);  
  } else {
    haloColor = c_mesh_glow; 
    coreColor = color(255, 220); 
  }
  
  float connectDist = width / 10.0; 
  if (distortionAmt > 0) connectDist += distortionAmt; 

  for (int i = 0; i < renderPoints.size(); i++) {
    PVector p1 = renderPoints.get(i);
    for (int j = i + 1; j < renderPoints.size(); j++) {
      PVector p2 = renderPoints.get(j);
      
      float d = PVector.dist(p1, p2);
      
      if (d < connectDist) {
        float alphaFactor = map(d, 0, connectDist, 255, 0);
        
        strokeWeight(3.5);
        stroke(haloColor, alphaFactor * 0.4); 
        line(p1.x, p1.y, p2.x, p2.y);
        
        strokeWeight(1.0);
        stroke(coreColor, alphaFactor * 0.9); 
        line(p1.x, p1.y, p2.x, p2.y);
      }
    }
  }
  
  if (distVal <= LOCK_DISTANCE) {
    stroke(c_mesh_lock, 150);
    strokeWeight(5);
    noFill();
    beginShape();
    for (PVector p : renderPoints) vertex(p.x, p.y);
    endShape(CLOSE);
    
    stroke(255);
    strokeWeight(1.5);
    noFill();
    beginShape();
    for (PVector p : renderPoints) vertex(p.x, p.y);
    endShape(CLOSE);
  }
}

// ==========================================
// [OSC Handling]
// ==========================================
void oscEvent(OscMessage msg) {
  if (msg.checkAddrPattern("/frame/start")) {
    currentFrameBlobs.clear();
    return;
  }
  if (msg.checkAddrPattern("/frame/end")) {
    findFastestBlob();
    return;
  }
  if (msg.checkAddrPattern("/update")) {
    int id = msg.get(0).intValue();
    float nx = msg.get(1).floatValue();
    float ny = msg.get(2).floatValue();
    float speed = msg.get(3).floatValue();
    
    // --- Get Semantic X/Y from Python (Index 4 & 5) ---
    float semX = msg.get(4).floatValue(); 
    float semY = msg.get(5).floatValue(); 
    float distance = msg.get(6).floatValue();
    
    BlobData newBlob = new BlobData();
    newBlob.id = id;
    newBlob.center = new PVector(nx * width, ny * height);
    newBlob.speed = speed;
    newBlob.semX = semX; // Store for color calculation
    newBlob.semY = semY; // Store for color calculation
    newBlob.distance = distance;
    
    int startIdx = 7;
    for (int i = 0; i < NUM_POINTS; i++) {
      int xIdx = startIdx + (i * 2);
      int yIdx = startIdx + (i * 2) + 1;
      if (yIdx < msg.arguments().length) {
         newBlob.points.add(new PVector(msg.get(xIdx).floatValue() * width, msg.get(yIdx).floatValue() * height));
      }
    }
    currentFrameBlobs.add(newBlob);
  }
}

void findFastestBlob() {
  if (currentFrameBlobs.size() == 0) return;
  float maxSpeed = -1;
  int maxIndex = -1;
  for (int i = 0; i < currentFrameBlobs.size(); i++) {
    if (currentFrameBlobs.get(i).speed > maxSpeed) {
      maxSpeed = currentFrameBlobs.get(i).speed;
      maxIndex = i;
    }
  }
  if (maxIndex != -1) targetBlob = currentFrameBlobs.get(maxIndex);
}

class BlobData {
  int id;
  PVector center;
  float speed;
  float semX, semY; // Semantic Coordinates
  float distance;
  ArrayList<PVector> points;
  BlobData() {
    center = new PVector();
    points = new ArrayList<PVector>();
  }
}

// ==========================================
// [Particle Class]
// ==========================================
class Particle {
  PVector loc, prevLoc, vel, acc;
  int lifeSpan, passedLife;
  boolean dead;
  float alpha, weight, weightRange, decay, xOfst, yOfst;
  color pColor; 
  
  Particle(float x, float y, float xOfst, float yOfst, color c){
    loc = new PVector(x, y);
    prevLoc = new PVector(x, y);
    pColor = c;
    
    float randDegrees = random(360);
    vel = new PVector(cos(radians(randDegrees)), sin(radians(randDegrees)));
    vel.mult(random(2, 5)); 
    
    acc = new PVector(0,0);
    lifeSpan = int(random(10, 40));
    decay = random(0.85, 0.95); 
    
    weightRange = random(1, 4);
    
    this.xOfst = xOfst;
    this.yOfst = yOfst;
  }
  
  void update(){
    if(passedLife >= lifeSpan){
      dead = true;
    } else {
      passedLife++;
    }
    
    alpha = float(lifeSpan-passedLife)/lifeSpan * 150 + 50; 
    weight = float(lifeSpan-passedLife)/lifeSpan * weightRange;
    
    acc.set(0,0);
    
    float rn = (noise((loc.x+frameCount+xOfst)*.01, (loc.y+frameCount+yOfst)*.01)-.5)*TWO_PI*4;
    float mag = noise((loc.y-frameCount)*.33, (loc.x-frameCount)*.33);
    PVector dir = new PVector(cos(rn),sin(rn));
    acc.add(dir);
    acc.mult(mag);
    
    float randRn = random(TWO_PI);
    PVector randV = new PVector(cos(randRn), sin(randRn));
    randV.mult(.25);
    acc.add(randV);
    
    vel.add(acc);
    vel.mult(decay);
    vel.limit(3);
    
    prevLoc.x = loc.x;
    prevLoc.y = loc.y;
    
    loc.add(vel);
  }
  
  void display(PGraphics pg){
    pg.strokeWeight(0.8); 
    pg.stroke(pColor, alpha); 
    pg.line(prevLoc.x, prevLoc.y, loc.x, loc.y);
    
    pg.strokeWeight(weight + 2.0);
    pg.stroke(pColor, alpha * 0.1); 
    pg.line(prevLoc.x, prevLoc.y, loc.x, loc.y);
  }
}
